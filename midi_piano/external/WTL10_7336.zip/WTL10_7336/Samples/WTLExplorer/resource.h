//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by WTLExplorer.rc
//
#define ID_COMBO_GO                     101
#define ID_VIEW_ICONS                   102
#define ID_VIEW_DETAILS                 103
#define ID_VIEW_SMALL_ICONS             104
#define ID_VIEW_LIST                    105
#define ID_VIEW_SORT_NAME               106
#define ID_VIEW_SORT_SIZE               107
#define ID_VIEW_SORT_TYPE               108
#define ID_VIEW_SORT_TIME               109
#define ID_VIEW_SORT_ATTR               110
#define IDR_MAINFRAME                   128
#define IDT_GO                          202
#define IDT_GO1                         203
#define ID_FILE_NEW_WINDOW              32771
#define ID_VIEW_ADDRESS_BAR             32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        201
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
