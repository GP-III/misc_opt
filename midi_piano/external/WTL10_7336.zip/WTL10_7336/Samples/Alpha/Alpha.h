// Alpha.h
