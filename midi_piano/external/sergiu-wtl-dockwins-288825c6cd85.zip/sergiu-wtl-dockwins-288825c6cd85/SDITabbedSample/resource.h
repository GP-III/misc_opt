//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SDISample.rc
//
#define IDD_ABOUTBOX                    100
#define IDR_MAINFRAME                   128
#define IDB_DUMMYBMP                    201
#define IDI_ICON1                       202
#define IDI_ICON2                       203
#define IDI_ICON3                       204
#define IDI_ICON4                       205
#define ID_FILE_NEW_WINDOW              32771
#define ID_VIEW_FOLDERS                 32772
#define ID_VIEW_OUTPUT                  32773
#define ID_VIEW_SAMPLE_WND1             32774
#define ID_VIEW_SAMPLE_WND2             32775
#define ID_VIEW_SAMPLE_WND3             32776
#define ID_VIEW_SAMPLE_WND4             32777

// Next default values for new objects
//
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        206
#define _APS_NEXT_COMMAND_VALUE         32778
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
