WTL Docking Windows Library
===========================

This projects represents a fork of Sergey Klimov's WTL docking windows library.
It aims at fixing and imporving the library.

Getting Started
===============

To use the library a recent version of WTL and Visual Studio 2010 is required.
