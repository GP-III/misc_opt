#pragma once

#include <atlbase.h>
#include <atlapp.h>
#include <atlmisc.h>

#include <DockImpl.cpp>
