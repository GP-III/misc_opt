// MDISample.h
