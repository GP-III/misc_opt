// MDIExSample.h
